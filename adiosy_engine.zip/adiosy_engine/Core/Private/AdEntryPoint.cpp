﻿#include "AdEntryPoint.h"

namespace ade
{

}