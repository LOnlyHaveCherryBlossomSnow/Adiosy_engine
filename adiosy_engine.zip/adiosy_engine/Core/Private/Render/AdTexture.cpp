#include "Render/AdTexture.h"  // 引入纹理相关的头文件

#include "AdApplication.h"      // 引入应用程序头文件
#include "Render/AdRenderContext.h"  // 引入渲染上下文头文件
#include "Graphic/AdVKDevice.h"     // 引入 Vulkan 设备头文件
#include "Graphic/AdVKImage.h"      // 引入 Vulkan 图像头文件
#include "Graphic/AdVKImageView.h"  // 引入 Vulkan 图像视图头文件
#include "Graphic/AdVKBuffer.h"     // 引入 Vulkan 缓冲区头文件

#define STB_IMAGE_IMPLEMENTATION   // 定义 STB 图像库的实现，允许加载图像
#include "stb/stb_image.h"  // 引入 stb_image 库，用于加载图片

namespace ade {

    // 构造函数：通过文件路径加载纹理图片
    AdTexture::AdTexture(const std::string &filePath) 
    {
        int numChannel;  // 用于存储图片的通道数
        // 加载图片数据，STBI_rgb_alpha 表示加载为 RGBA 格式
        uint8_t *data = stbi_load(filePath.c_str(), reinterpret_cast<int *>(&mWidth), 
                                  reinterpret_cast<int *>(&mHeight), &numChannel, STBI_rgb_alpha);
        // 如果图片加载失败，打印错误并返回
        if (!data) 
        {
            LOG_E("AdTexture Can not load this image: {0}", filePath);
            return;
        }
        // 设置纹理的格式为 VK_FORMAT_R8G8B8A8_UNORM（标准 RGBA 格式）
        mFormat = VK_FORMAT_R8G8B8A8_UNORM;
        // 创建线性过滤器、重复地址模式的纹理采样器
        // CALL_VK(device->CreateSimpleSampler(VK_FILTER_LINEAR, VK_SAMPLER_ADDRESS_MODE_REPEAT, &mSampler));
        // 将图片数据复制到缓冲区
        size_t size = sizeof(uint8_t) * 4 * mWidth * mHeight;  // 计算图片的总大小（RGBA）
        //清理图片
        CreateImage(size, data);

        // 释放图片数据
        stbi_image_free(data);
    }
    AdTexture::AdTexture(uint32_t width, uint32_t height, RGBAColor *pixels) : mWidth(width), mHeight(height) 
    {   
        // 设置纹理的格式为 VK_FORMAT_R8G8B8A8_UNORM（标准 RGBA 格式）
        mFormat = VK_FORMAT_R8G8B8A8_UNORM;//mipmap
        size_t size = sizeof(uint8_t) * 4 * mWidth * mHeight;
        CreateImage(size, pixels);
    }


    // 析构函数：释放资源
    AdTexture::~AdTexture() 
    {
        // 删除采样器
        // VK_D(Sampler, device->GetHandle(), mSampler);

        // 重置图像视图和图像
        mImageView.reset();
        mImage.reset();
    }
    void AdTexture::CreateImage(size_t size, void *data) 
    {
         // 获取渲染上下文和设备
        ade::AdRenderContext *renderCxt = AdApplication::GetAppContext()->renderCxt;
        ade::AdVKDevice *device = renderCxt->GetDevice();
        // 创建 Vulkan 图像（大小为 mWidth x mHeight，格式为 mFormat，包含两种用途：传输目标和可采样）
        mImage = std::make_shared<AdVKImage>(device, VkExtent3D{ mWidth, mHeight, 1 }, 
                 mFormat, VK_IMAGE_USAGE_TRANSFER_DST_BIT | VK_IMAGE_USAGE_SAMPLED_BIT, 
                 VK_SAMPLE_COUNT_1_BIT);
        // 创建图像视图
        mImageView = std::make_shared<AdVKImageView>(device, mImage->GetHandle(), mFormat, VK_IMAGE_ASPECT_COLOR_BIT);

        // copy data to buffer
        std::shared_ptr<AdVKBuffer> stageBuffer = std::make_shared<AdVKBuffer>(device, VK_BUFFER_USAGE_TRANSFER_SRC_BIT, size, data, true);

        // copy buffer to image
         // UNDEFINED -> TRANSFER_DST -> copy -> SHADER_READ_ONLY_OPTIMAL
        // 将图像的布局转换为可进行传输的状态
        VkCommandBuffer cmdBuffer = device->CreateAndBeginOneCmdBuffer();
        AdVKImage::TransitionLayout(cmdBuffer, mImage->GetHandle(), VK_IMAGE_LAYOUT_UNDEFINED, VK_IMAGE_LAYOUT_TRANSFER_DST_OPTIMAL);
        // 将缓冲区中的数据拷贝到 Vulkan 图像
        mImage->CopyFromBuffer(cmdBuffer, stageBuffer.get());
          // 将图像的布局转换为着色器只读状态
        AdVKImage::TransitionLayout(cmdBuffer, mImage->GetHandle(), VK_IMAGE_LAYOUT_TRANSFER_DST_OPTIMAL, VK_IMAGE_LAYOUT_SHADER_READ_ONLY_OPTIMAL);
         // 提交命令缓冲区
        device->SubmitOneCmdBuffer(cmdBuffer);
         // 清理缓冲区
        stageBuffer.reset();
    }

}
