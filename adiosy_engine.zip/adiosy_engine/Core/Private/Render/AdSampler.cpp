#include "Render/AdSampler.h"


#include "AdApplication.h"      // 引入应用程序头文件
#include "Render/AdRenderContext.h"  // 引入渲染上下文头文件

namespace ade
{

    AdSampler::AdSampler(VkFilter filter, VkSamplerAddressMode addressMode) : mFilter(filter), mAddressMode(addressMode)
    {
        ade::AdRenderContext *renderCxt = AdApplication::GetAppContext()->renderCxt;
        ade::AdVKDevice *device = renderCxt->GetDevice();
        CALL_VK(device->CreateSimpleSampler(VK_FILTER_LINEAR, VK_SAMPLER_ADDRESS_MODE_REPEAT, &mHandle));//定义
        
    }
    AdSampler::~AdSampler()
    {
        ade::AdRenderContext *renderCxt = AdApplication::GetAppContext()->renderCxt;
        ade::AdVKDevice *device = renderCxt->GetDevice();
        VK_D(Sampler, device->GetHandle(), mHandle);//释放

    }

}


