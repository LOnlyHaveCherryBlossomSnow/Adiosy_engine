﻿#include "AdApplication.h"
#include "AdLog.h"
#include "Render/AdRenderContext.h"
#include "ECS/AdEntity.h"

namespace ade {
    // 静态成员变量，用于存储应用的上下文
    AdAppContext AdApplication::sAppContext{};

    // 启动应用程序的主方法
    void AdApplication::Start(int argc, char **argv) 
    {
        // 初始化日志系统
        AdLog::Init();

        // 解析命令行参数
        ParseArgs(argc, argv);

        // 通过应用的设置（如窗口宽高、标题等）来进行窗口的创建
        OnConfiguration(&mAppSettings);
        mWindow = AdWindow::Create(mAppSettings.width, mAppSettings.height, mAppSettings.title);

        // 创建渲染上下文，并将其存储为共享指针
        mRenderContext = std::make_shared<AdRenderContext>(mWindow.get());

        // 将当前应用上下文的指针和渲染上下文指针存入全局静态变量 `sAppContext`
        sAppContext.app = this;
        sAppContext.renderCxt = mRenderContext.get();

        // 执行额外的初始化（比如其他资源的加载或设置）
        OnInit();
        LoadScene();

        // 记录应用启动时的时间戳
        mStartTimePoint = std::chrono::steady_clock::now();
    }

    // 停止应用程序时的清理工作
    void AdApplication::Stop() 
    {
        // 执行销毁操作，通常是资源释放和清理
        //默认的时候卸载场景
        UnLoadScene();
        OnDestroy();
    }

    // 应用程序的主循环方法
    void AdApplication::MainLoop()
    {
        // 记录程序启动时的时间戳
        mLastTimePoint = std::chrono::steady_clock::now();

        // 循环直到窗口关闭
        while (!mWindow->ShouldClose()) 
        {
            // 轮询窗口事件（比如按键、鼠标事件等）
            mWindow->PollEvents();

            // 计算时间差，作为每一帧的时间间隔
            float deltaTime = std::chrono::duration<float>(std::chrono::steady_clock::now() - mLastTimePoint).count();
            mLastTimePoint = std::chrono::steady_clock::now();

            // 增加帧计数器
            mFrameIndex++;

            // 如果没有暂停，执行更新操作
            if (!bPause) 
            {
                OnUpdate(deltaTime);
            }

            // 渲染当前帧
            OnRender();
            // 交换缓冲区，显示当前帧
            mWindow->SwapBuffer();
        }
    }

    // 用于解析命令行参数
    void AdApplication::ParseArgs(int argc, char **argv)
    {
        // 此处可以实现对命令行参数的解析，例如设置应用的一些特性
        // TODO: 在此函数中实现相关的逻辑
    }
    
    bool AdApplication::LoadScene(const std::string &filePath) 
    {
        if(mScene)//场景是否存在
        {
            UnLoadScene();//卸载
        }
        mScene = std::make_unique<AdScene>();//创建空场景
        OnSceneInit(mScene.get());
        sAppContext.scene = mScene.get();
        return true;
    }

    void AdApplication::UnLoadScene() //卸载创建
    {
        if(mScene)
        {
            OnSceneDestroy(mScene.get());
            mScene.reset();
            sAppContext.scene = nullptr;//制空
        }
    }
}
