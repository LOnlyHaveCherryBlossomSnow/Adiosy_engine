#include "ECS/System/AdBaseMaterialSystem.h"
#include "AdFileUtil.h"
#include "AdGeometryUtil.h"
#include "AdApplication.h"

#include "Render/AdRenderContext.h"
#include "Render/AdRenderTarget.h"

#include "Graphic/AdVKPipeline.h"
#include "Graphic/AdVKFrameBuffer.h"

#include "ECS/AdEntity.h"
#include "ECS/Component/AdLookAtCameraComponent.h"

namespace ade{
    void AdBaseMaterialSystem::OnInit(AdVKRenderPass *renderPass) 
    {
        ade::AdRenderContext *renderCxt = AdApplication::GetAppContext()->renderCxt;
        ade::AdVKDevice *device = renderCxt->GetDevice();

        ade::ShaderLayout shaderLayout = {
            .pushConstants = {
                {
                    .stageFlags = VK_SHADER_STAGE_VERTEX_BIT,
                    .offset = 0,
                    .size = sizeof(PushConstants)
                }
            }
        };
        mPipelineLayout = std::make_shared<AdVKPipelineLayout>(device,
                                                               AD_RES_SHADER_DIR"01_hello_buffer.vert",
                                                               AD_RES_SHADER_DIR"01_hello_buffer.frag",
                                                               shaderLayout);
        std::vector<VkVertexInputBindingDescription> vertexBindings = {
            {
                .binding = 0,
                .stride = sizeof(AdVertex),
                .inputRate = VK_VERTEX_INPUT_RATE_VERTEX
            }
        };
        std::vector<VkVertexInputAttributeDescription> vertexAttrs = {
            {
                .location = 0,
                .binding = 0,
                .format = VK_FORMAT_R32G32B32_SFLOAT,
                .offset = offsetof(AdVertex, position)
            },
            {
                .location = 1,
                .binding = 0,
                .format = VK_FORMAT_R32G32_SFLOAT,
                .offset = offsetof(AdVertex, texcoord0)
            },
            {
                .location = 2,
                .binding = 0,
                .format = VK_FORMAT_R32G32B32_SFLOAT,
                .offset = offsetof(AdVertex, normal)
            }
        };
        mPipeline = std::make_shared<AdVKPipeline>(device, renderPass, mPipelineLayout.get());
        mPipeline->SetVertexInputState(vertexBindings, vertexAttrs);
        mPipeline->SetInputAssemblyState(VK_PRIMITIVE_TOPOLOGY_TRIANGLE_LIST)->EnableDepthTest();
        mPipeline->SetDynamicState({ VK_DYNAMIC_STATE_VIEWPORT, VK_DYNAMIC_STATE_SCISSOR });
        mPipeline->SetMultisampleState(VK_SAMPLE_COUNT_4_BIT, VK_FALSE);
        mPipeline->Create();
    }

    void AdBaseMaterialSystem::OnRender(VkCommandBuffer cmdBuffer, AdRenderTarget *renderTarget) 
    {
        
        // entt::each  便利组件
        AdAppContext *appContext = AdApplication::GetAppContext();
        AdApplication *app = appContext->app;
        AdScene *scene = appContext->scene;//添加场景
        if(!scene)//没场景
        {
            return;
        }

        entt::registry &reg = scene->GetEcsRegistry();//注册器
        //需要的组件           transform                      mateiral
        auto view = reg.view<AdTransformComponent,AdBaseMaterialComponent>();
        if(view.begin() == view.end())//是否有实体
        {
            return;
        }
        // bind pipeline  绑定pipeline
        mPipeline->Bind(cmdBuffer);
        // setup global params  全局参数
        AdVKFrameBuffer *frameBuffer = renderTarget->GetFrameBuffer();
        VkViewport viewport = 
        {
            .x = 0,
            .y = 0,
            .width = static_cast<float>(frameBuffer->GetWidth()),
            .height = static_cast<float>(frameBuffer->GetHeight()),
            .minDepth = 0.f,
            .maxDepth = 1.f
        };
        vkCmdSetViewport(cmdBuffer, 0, 1, &viewport);
        VkRect2D scissor = 
        {
            .offset = { 0, 0 },
            .extent = { frameBuffer->GetWidth(), frameBuffer->GetHeight() }
        };
        vkCmdSetScissor(cmdBuffer, 0, 1, &scissor);


        // TODO CameraComponent  相机组件
        //glm::mat4 projMat = glm::perspective(glm::radians(65.f), frameBuffer->GetWidth() * 1.f / frameBuffer->GetHeight(), 0.01f, 100.f);
        //projMat[1][1] *= -1.f;
        //glm::mat4 viewMat = glm::lookAt(glm::vec3{ 0, 0, 1.5f }, glm::vec3{ 0, 0, -1 }, glm::vec3{ 0, 1, 0 });
        glm::mat4 projMat{1.0f};
        glm::mat4 viewMat{1.0f};
        AdEntity *camera = renderTarget->GetCamera();
        if(AdEntity::HasComponent<AdLookAtCameraComponent>(camera))
        {
            auto &cameraComp = camera->GetComponent<AdLookAtCameraComponent>();
            projMat = cameraComp.GetProjMat();
            viewMat = cameraComp.GetViewMat();
        }



        // setup custom params  自定义参数 
        //循环
        view.each([this, &cmdBuffer, &projMat, &viewMat](const auto &e, const AdTransformComponent &transComp, const AdBaseMaterialComponent &materialComp)
        {
            // 拿到所有材质
            auto meshMaterials = materialComp.GetMeshMaterials();
            for (const auto &entry: meshMaterials)
            {
                AdBaseMaterial *material = entry.first;
                if(!material)//材质不存在就不渲染
                {
                    LOG_W("TODO: default material or error material ?");
                    continue;
                }
                PushConstants pushConstants 
                {
                        .matrix = projMat * viewMat * transComp.GetTransform(),
                        .colorType = material->colorType//具体某个材质
                };
                vkCmdPushConstants(cmdBuffer, mPipelineLayout->GetHandle(), VK_SHADER_STAGE_VERTEX_BIT, 0, sizeof(pushConstants), &pushConstants);

                // mesh list draw  具体mesh 绘制
                for (const auto &meshIndex: entry.second)
                {
                    AdMesh *mesh = materialComp.GetMesh(meshIndex);
                    if(mesh){
                        mesh->Draw(cmdBuffer);
                    }
                }
            }
        });
        
        //LOG_T("每帧渲染:{0},{1}",__FUNCTION__,"(来自AdBaseMaterialSystem)");
    }

    void AdBaseMaterialSystem::OnDestroy() 
    {
        mPipeline.reset();
        mPipelineLayout.reset();
    }
}