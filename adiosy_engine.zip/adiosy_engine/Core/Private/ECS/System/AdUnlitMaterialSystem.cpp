#include "ECS/System/AdUnlitMaterialSystem.h"

#include "AdFileUtil.h"
#include "AdApplication.h"
#include "Graphic/AdVKPipeline.h"
#include "Graphic/AdVKDescriptorSet.h"
#include "Graphic/AdVKImageView.h"
#include "Graphic/AdVKFrameBuffer.h"

#include "Render/AdRenderTarget.h"

#include "ECS/Component/AdTransformComponent.h"

namespace ade
{
    //void AdUnlitMaterialSystem::OnInit(AdVKRenderPass *renderPass) 
    //{
    //    AdVKDevice *device = GetDevice();
//
    //}
} 