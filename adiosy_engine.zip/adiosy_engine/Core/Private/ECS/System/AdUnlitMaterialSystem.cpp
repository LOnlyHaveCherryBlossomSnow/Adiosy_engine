#include "ECS/System/AdUnlitMaterialSystem.h"

#include "AdFileUtil.h"
#include "AdApplication.h"
#include "Graphic/AdVKPipeline.h"
#include "Graphic/AdVKDescriptorSet.h"
#include "Graphic/AdVKImageView.h"
#include "Graphic/AdVKFrameBuffer.h"

#include "Render/AdRenderTarget.h"

#include "ECS/Component/AdTransformComponent.h"

namespace ade
{
    void AdUnlitMaterialSystem::OnInit(AdVKRenderPass *renderPass) 
    {
        AdVKDevice *device = GetDevice();
          //Frame Ubo
          {
            const std::vector<VkDescriptorSetLayoutBinding> bindings = 
            {
               {
                   .binding = 0,
                   .descriptorType = VK_DESCRIPTOR_TYPE_UNIFORM_BUFFER,//binding0 UNIFORM_BUFFER
                   .descriptorCount = 1,
                   .stageFlags = VK_SHADER_STAGE_VERTEX_BIT | VK_SHADER_STAGE_FRAGMENT_BIT,
               }
           };
           mFrameUboDescSetLayout = std::make_shared<AdVKDescriptorSetLayout>(device, bindings);
       }

       // Material Params 材质参数
       {
           const std::vector<VkDescriptorSetLayoutBinding> bindings = 
           {
               {
                   .binding = 0,
                   .descriptorType = VK_DESCRIPTOR_TYPE_UNIFORM_BUFFER,
                   .descriptorCount = 1,
                   .stageFlags = VK_SHADER_STAGE_FRAGMENT_BIT
               }
           };
           mMaterialParamDescSetLayout = std::make_shared<AdVKDescriptorSetLayout>(device, bindings);
       }

       // Material Resource 材质纹理
       {
           const std::vector<VkDescriptorSetLayoutBinding> bindings = 
           {
               {
                   .binding = 0,//texture 0
                   .descriptorType = VK_DESCRIPTOR_TYPE_COMBINED_IMAGE_SAMPLER,
                   .descriptorCount = 1,
                   .stageFlags = VK_SHADER_STAGE_FRAGMENT_BIT
               },
               {
                   .binding = 1,//texture 1
                   .descriptorType = VK_DESCRIPTOR_TYPE_COMBINED_IMAGE_SAMPLER,
                   .descriptorCount = 1,
                   .stageFlags = VK_SHADER_STAGE_FRAGMENT_BIT
               }
           };
           mMaterialResourceDescSetLayout = std::make_shared<AdVKDescriptorSetLayout>(device, bindings);
       }

        VkPushConstantRange modelPC = {
                                    .stageFlags = VK_SHADER_STAGE_VERTEX_BIT,
                                    .offset = 0,
                                    .size = sizeof(ModelPC)
                                    };  
        ShaderLayout shaderLayout = {//要传的常量
                                    .descriptorSetLayouts = { mFrameUboDescSetLayout->GetHandle(), mMaterialParamDescSetLayout->GetHandle(), mMaterialResourceDescSetLayout->GetHandle() },
                                    .pushConstants = { modelPC }//要推送的常量
                                    };

        mPipelineLayout = std::make_shared<AdVKPipelineLayout>(device,//逻辑设备
                                                                AD_RES_SHADER_DIR"03_unlit_material.vert",//顶点着色器
                                                                AD_RES_SHADER_DIR"03_unlit_material.frag",//片源着色器
                                                                shaderLayout);//要传的常量  
        std::vector<VkVertexInputBindingDescription> vertexBindings = 
        {
            {
                .binding = 0,
                .stride = sizeof(AdVertex),
                .inputRate = VK_VERTEX_INPUT_RATE_VERTEX
            }
        };
        std::vector<VkVertexInputAttributeDescription> vertexAttrs = 
        {
            {
                .location = 0,
                .binding = 0,
                .format = VK_FORMAT_R32G32B32_SFLOAT,
                .offset = offsetof(AdVertex, position)
            },
            {
                .location = 1,
                .binding = 0,
                .format = VK_FORMAT_R32G32_SFLOAT,
                .offset = offsetof(AdVertex, texcoord0)
            },
            { 
                .location = 2,
                .binding = 0,
                .format = VK_FORMAT_R32G32B32_SFLOAT,
                .offset = offsetof(AdVertex, normal)
            }
        };
        mPipeline = std::make_shared<AdVKPipeline>(device, renderPass, mPipelineLayout.get());
        mPipeline->SetVertexInputState(vertexBindings, vertexAttrs);//顶点输入的状态
        mPipeline->EnableDepthTest();//开始深度测试
        mPipeline->SetDynamicState({ VK_DYNAMIC_STATE_VIEWPORT, VK_DYNAMIC_STATE_SCISSOR });//动态的几个状态
        mPipeline->SetMultisampleState(VK_SAMPLE_COUNT_4_BIT, VK_FALSE);//多重采样
        mPipeline->Create();

        std::vector<VkDescriptorPoolSize> poolSizes = 
        {
            {
                .type = VK_DESCRIPTOR_TYPE_UNIFORM_BUFFER,//UNIFORM_BUFFER
                .descriptorCount = 1
            }
        };
        mDescriptorPool = std::make_shared<AdVKDescriptorPool>(device, 1, poolSizes);//描述符池
        mFrameUboDescSet = mDescriptorPool->AllocateDescriptorSet(mFrameUboDescSetLayout.get(), 1)[0];//描述符集
        mFrameUboBuffer = std::make_shared<ade::AdVKBuffer>(device, VK_BUFFER_USAGE_UNIFORM_BUFFER_BIT, sizeof(FrameUbo), nullptr, true);//初始化

        ReCreateMaterialDescPool(NUM_MATERIAL_BATCH);//默认16 最大2048
    }


    void AdUnlitMaterialSystem::OnRender(VkCommandBuffer cmdBuffer, AdRenderTarget *renderTarget) 
    {   //渲染
        AdScene *scene = GetScene();//获取场景 判断是否有场景
        if(!scene)
        {
            return;
        }
        entt::registry &reg = scene->GetEcsRegistry();//场景注册器

        auto view = reg.view<AdTransformComponent, AdUnlitMaterialComponent>();
        if(view.begin() == view.end())//是否有对应的组件
        {
            return;
        }

        mPipeline->Bind(cmdBuffer);//绑定渲染管线
        AdVKFrameBuffer *frameBuffer = renderTarget->GetFrameBuffer();
        VkViewport viewport = 
        {
            .x = 0,
            .y = 0,
            .width = static_cast<float>(frameBuffer->GetWidth()),
            .height = static_cast<float>(frameBuffer->GetHeight()),
            .minDepth = 0.f,
            .maxDepth = 1.f
        };
        vkCmdSetViewport(cmdBuffer, 0, 1, &viewport);//设置动态参数
        VkRect2D scissor = 
        {
            .offset = { 0, 0 },
            .extent = { frameBuffer->GetWidth(), frameBuffer->GetHeight() }
        };
        vkCmdSetScissor(cmdBuffer, 0, 1, &scissor);

        UpdateFrameUboDescSet(renderTarget);//更新每一帧

        bool bShouldForceUpdateMaterial = false;//是否要动态扩容
        uint32_t materialCount = AdMaterialFactory::GetInstance()->GetMaterialSize<AdUnlitMaterial>();//获取材质数量
        if(materialCount > mLastDescriptorSetCount)
        {
            ReCreateMaterialDescPool(materialCount);//扩容
            bShouldForceUpdateMaterial = true;
        }

        std::vector<bool> updateFlags(materialCount);//记录材质是否更新
        view.each([this, &updateFlags, &bShouldForceUpdateMaterial, &cmdBuffer](AdTransformComponent &transComp, AdUnlitMaterialComponent &materialComp)
        {
            for (const auto &entry: materialComp.GetMeshMaterials())//拿到所有材质
            {
                AdUnlitMaterial *material = entry.first;
                if(!material || material->GetIndex() < 0)
                {
                    LOG_W("AdUnlitMaterialSystem TODO: default material or error material ?");
                    continue;
                }

                uint32_t materialIndex = material->GetIndex();//拿到材质索引
                VkDescriptorSet paramsDescSet = mMaterialDescSets[materialIndex];//材质参数的descset
                VkDescriptorSet resourceDescSet = mMaterialResourceDescSets[materialIndex];//纹理descset

                if(!updateFlags[materialIndex])//没有更新 才去更新
                {
                    if(material->ShouldFlushParams() || bShouldForceUpdateMaterial)//纹理是否更新
                    {
                        LOG_T("AdUnlitMaterialSystem Update material params : {0}", materialIndex);
                        UpdateMaterialParamsDescSet(paramsDescSet, material);
                        material->FinishFlushParams();
                    }
                    if(material->ShouldFlushResource() || bShouldForceUpdateMaterial)
                    {
                        LOG_T("AdUnlitMaterialSystem Update material resource : {0}", materialIndex);
                        UpdateMaterialResourceDescSet(resourceDescSet, material);
                        material->FinishFlushResource();
                    }
                    updateFlags[materialIndex] = true;

                }
                                    
                VkDescriptorSet descriptorSets[] = { mFrameUboDescSet, paramsDescSet, resourceDescSet };    
                vkCmdBindDescriptorSets(cmdBuffer, VK_PIPELINE_BIND_POINT_GRAPHICS, mPipelineLayout->GetHandle(),
                                        0, ARRAY_SIZE(descriptorSets), descriptorSets, 0, nullptr);//绑定descset

                ModelPC pc = { transComp.GetTransform() };//结构体
                vkCmdPushConstants(cmdBuffer, mPipelineLayout->GetHandle(), VK_SHADER_STAGE_VERTEX_BIT, 0, sizeof(pc), &pc);//推送

                for (const auto &meshIndex: entry.second)
                {
                    materialComp.GetMesh(meshIndex)->Draw(cmdBuffer);//绘制
                }
            }
        });
    }

    void AdUnlitMaterialSystem::OnDestroy() {

    }

    void AdUnlitMaterialSystem::ReCreateMaterialDescPool(uint32_t materialCount) //动态扩容
    {
        AdVKDevice *device = GetDevice();

        uint32_t newDescriptorSetCount = mLastDescriptorSetCount;//最新池子需要放多少个
        if(mLastDescriptorSetCount == 0)
        {
            newDescriptorSetCount = NUM_MATERIAL_BATCH;
        }

        while (newDescriptorSetCount < materialCount) 
        {
            newDescriptorSetCount *= 2;//2倍数增长  直到大于材质数量
        }

        if(newDescriptorSetCount > NUM_MATERIAL_BATCH_MAX)//大于最大的数量就报错
        {
            LOG_E("AdUnlitMaterialSystem Descriptor Set max count is : {0}, but request : {1}", NUM_MATERIAL_BATCH_MAX, newDescriptorSetCount);
            return;
        }

        LOG_W("{0}: {1} -> {2} S.", __FUNCTION__, mLastDescriptorSetCount, newDescriptorSetCount);

        // Destroy old  清空销毁
        mMaterialDescSets.clear();
        mMaterialResourceDescSets.clear();
        if(mMaterialDescriptorPool){mMaterialDescriptorPool.reset();}//销毁之后重新定义pool

        std::vector<VkDescriptorPoolSize> poolSizes = 
        {
            {
                .type = VK_DESCRIPTOR_TYPE_UNIFORM_BUFFER,//材质里面就只定义了uniform buffer
                .descriptorCount = newDescriptorSetCount
            },
            {
                .type = VK_DESCRIPTOR_TYPE_COMBINED_IMAGE_SAMPLER,
                .descriptorCount = newDescriptorSetCount * 2               // because has color_tex0 and color_tex1  *2有两个纹理
            }
        };
        mMaterialDescriptorPool = std::make_shared<ade::AdVKDescriptorPool>(device, newDescriptorSetCount * 2, poolSizes);  //because has params and resource desc. set  申请材质描述符池
        //申请纹理的Set
        mMaterialDescSets = mMaterialDescriptorPool->AllocateDescriptorSet(mMaterialParamDescSetLayout.get(), newDescriptorSetCount);
        mMaterialResourceDescSets = mMaterialDescriptorPool->AllocateDescriptorSet(mMaterialResourceDescSetLayout.get(), newDescriptorSetCount);
        assert(mMaterialDescSets.size() == newDescriptorSetCount && "Failed to AllocateDescriptorSet");
        assert(mMaterialResourceDescSets.size() == newDescriptorSetCount && "Failed to AllocateDescriptorSet");

        uint32_t diffCount = newDescriptorSetCount - mLastDescriptorSetCount;
        for(int i = 0; i < diffCount; i++)
        {
            mMaterialBuffers.push_back(std::make_shared<AdVKBuffer>(device, VK_BUFFER_USAGE_UNIFORM_BUFFER_BIT, sizeof(UnlitMaterialUbo), nullptr, true));
        }
        LOG_W("{0}: {1} -> {2} E.", __FUNCTION__, mLastDescriptorSetCount, newDescriptorSetCount);
        mLastDescriptorSetCount = newDescriptorSetCount;
    }

    void AdUnlitMaterialSystem::UpdateFrameUboDescSet(AdRenderTarget *renderTarget) 
    {
        AdApplication *app = GetApp();
        AdVKDevice *device = GetDevice();//逻辑设备

        AdVKFrameBuffer *frameBuffer = renderTarget->GetFrameBuffer();
        glm::ivec2 resolution = { frameBuffer->GetWidth(), frameBuffer->GetHeight() };

        FrameUbo frameUbo = {
            .projMat = GetProjMat(renderTarget),
            .viewMat = GetViewMat(renderTarget),
            .resolution = resolution,
            .frameId = static_cast<uint32_t>(app->GetFrameIndex()),
            .time = app->GetStartTimeSecond()
        };

        mFrameUboBuffer->WriteData(&frameUbo);//写数据Ubo
        VkDescriptorBufferInfo bufferInfo = DescriptorSetWriter::BuildBufferInfo(mFrameUboBuffer->GetHandle(), 0, sizeof(frameUbo));//ubobuffer
        VkWriteDescriptorSet bufferWrite = DescriptorSetWriter::WriteBuffer(mFrameUboDescSet, 0, VK_DESCRIPTOR_TYPE_UNIFORM_BUFFER, &bufferInfo);//写buffer
        DescriptorSetWriter::UpdateDescriptorSets(device->GetHandle(), { bufferWrite });
    }

    void AdUnlitMaterialSystem::UpdateMaterialParamsDescSet(VkDescriptorSet descSet, AdUnlitMaterial *material) //材质参数
    {
        AdVKDevice *device = GetDevice();

        AdVKBuffer *materialBuffer = mMaterialBuffers[material->GetIndex()].get();

        UnlitMaterialUbo params = material->GetParams();

        const TextureView *texture0 = material->GetTextureView(UNLIT_MAT_BASE_COLOR_0);
        //纹理参数更新
        if(texture0)
        {
            AdMaterial::UpdateTextureParams(texture0, &params.textureParam0);
        }

        const TextureView *texture1 = material->GetTextureView(UNLIT_MAT_BASE_COLOR_1);
        if(texture1)
        {
            AdMaterial::UpdateTextureParams(texture1, &params.textureParam1);
        }

        materialBuffer->WriteData(&params);
        VkDescriptorBufferInfo bufferInfo = DescriptorSetWriter::BuildBufferInfo(materialBuffer->GetHandle(), 0, sizeof(params));
        VkWriteDescriptorSet bufferWrite = DescriptorSetWriter::WriteBuffer(descSet, 0, VK_DESCRIPTOR_TYPE_UNIFORM_BUFFER, &bufferInfo);
        DescriptorSetWriter::UpdateDescriptorSets(device->GetHandle(), { bufferWrite });
    }

    void AdUnlitMaterialSystem::UpdateMaterialResourceDescSet(VkDescriptorSet descSet, AdUnlitMaterial *material) //材质资源更新
    {
        AdVKDevice *device = GetDevice();
        //优化
        const TextureView *texture0 = material->GetTextureView(UNLIT_MAT_BASE_COLOR_0);
        const TextureView *texture1 = material->GetTextureView(UNLIT_MAT_BASE_COLOR_1);

        VkDescriptorImageInfo textureInfo0 = DescriptorSetWriter::BuildImageInfo(texture0->sampler->GetHandle(), texture0->texture->GetImageView()->GetHandle());
        VkDescriptorImageInfo textureInfo1 = DescriptorSetWriter::BuildImageInfo(texture1->sampler->GetHandle(), texture1->texture->GetImageView()->GetHandle());
        //
        VkWriteDescriptorSet textureWrite0 = DescriptorSetWriter::WriteImage(descSet, 0, VK_DESCRIPTOR_TYPE_COMBINED_IMAGE_SAMPLER, &textureInfo0);
        VkWriteDescriptorSet textureWrite1 = DescriptorSetWriter::WriteImage(descSet, 1, VK_DESCRIPTOR_TYPE_COMBINED_IMAGE_SAMPLER, &textureInfo1);

        DescriptorSetWriter::UpdateDescriptorSets(device->GetHandle(), { textureWrite0, textureWrite1 });
    }
} 