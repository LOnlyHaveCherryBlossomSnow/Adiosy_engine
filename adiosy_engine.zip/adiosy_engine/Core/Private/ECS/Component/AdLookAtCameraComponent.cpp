#include "ECS/Component/AdLookAtCameraComponent.h"
#include "ECS/Component/AdTransformComponent.h"

namespace ade
{
    const glm::mat4 &AdLookAtCameraComponent::GetProjMat() 
    {                               //                 宽高比    远平面       近平面
        mProjMat = glm::perspective(glm::radians(mFov), mAspect, mNearPlane, mFarPlane);
        mProjMat[1][1] *= -1.f;
        return mProjMat;
    }

    const glm::mat4 &AdLookAtCameraComponent::GetViewMat() 
    {
        AdEntity *owner = GetOwner();//是否包含其他的组件
        if(AdEntity::HasComponent<AdTransformComponent>(owner))
        {
            auto &transComp = owner->GetComponent<AdTransformComponent>();//获取位置
            float yaw = transComp.rotation.x;
            float pitch = transComp.rotation.y;

            glm::vec3 direction;//根据偏航角 和俯仰角 刷出相机方向
            direction.x = cos(glm::radians(pitch)) * sin(glm::radians(yaw));
            direction.y = sin(glm::radians(pitch));
            direction.z = cos(glm::radians(pitch)) * cos(glm::radians(yaw));

            transComp.position = mTarget + direction * mRadius;//目标位置+方向 + 半径    = 最新位置

            mViewMat = glm::lookAt(transComp.position, mTarget, mWorldUp);//朝向
        }
        return mViewMat;
    }

    void AdLookAtCameraComponent::SetViewMat(const glm::mat4 &viewMat) 
    {
        // TODO
    }
}