#ifndef AD_MESH_COMPONENT_H
#define AD_MESH_COMPONENT_H

#include "Render/AdMesh.h"
#include "ECS/AdComponent.h"
//模型组件
namespace ade{
    struct AdMeshComponent : public AdComponent
    {
        AdMesh *mMesh = nullptr;
    };
}

#endif