#ifndef AD_TRANSFORM_COMPONENT_H
#define AD_TRANSFORM_COMPONENT_H

#include "ECS/AdComponent.h"
#include "AdGraphicContext.h"
//Transform  变换
namespace ade
{
    class AdTransformComponent : public AdComponent 
    {
        public:
            glm::vec3 position; //位置
            glm::vec3 rotation;  // 旋转
            glm::vec3 scale;    //缩放

            glm::mat4 GetTransform() const
            {
                glm::mat4 transMat = glm::translate(glm::mat4(1.f), position);
                glm::mat4 rotationMat = glm::rotate(glm::mat4(1.f), glm::radians(rotation.x), glm::vec3{ 1, 0, 0 });
                rotationMat = glm::rotate(rotationMat, glm::radians(rotation.y), glm::vec3{ 0, 1, 0 });
                rotationMat = glm::rotate(rotationMat, glm::radians(rotation.z), glm::vec3{ 0, 0, 1 });
                glm::mat4 scaleMat = glm::scale(glm::mat4(1.f), scale);
                return transMat * rotationMat * scaleMat;
            }
    };
}

#endif
