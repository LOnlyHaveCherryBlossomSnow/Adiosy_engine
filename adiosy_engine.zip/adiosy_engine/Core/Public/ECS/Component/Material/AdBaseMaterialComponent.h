#ifndef AD_BASE_MATERIAL_COMPONENT_H
#define AD_BASE_MATERIAL_COMPONENT_H

#include "AdMaterialComponent.h"
//材质
namespace ade{
    enum BaseMaterialColor
    {
        COLOR_TYPE_NORMAL = 0,//nomral
        COLOR_TYPE_TEXCOORD = 1//text
    };

    struct AdBaseMaterial : public AdMaterial
    {
        BaseMaterialColor colorType;
    };

    struct AdBaseMaterialComponent : public AdMaterialComponent<AdBaseMaterial> 
    {

    };
}

#endif
