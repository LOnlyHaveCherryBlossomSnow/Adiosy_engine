#ifndef ADBASERENDERCOMPONENT_H
#define ADBASERENDERCOMPONENT_H

#include "ECS/AdComponent.h"
//材质
namespace ade{
    enum BaseMaterialColor
    {
        COLOR_TYPE_NORMAL = 0,//nomral
        COLOR_TYPE_TEXCOORD = 1//text
    };

    struct AdBaseMaterialComponent : public AdComponent 
    {
        BaseMaterialColor colorType;
    };
}

#endif