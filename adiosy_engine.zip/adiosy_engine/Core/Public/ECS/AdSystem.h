#ifndef AD_SYSTEM_H
#define AD_SYSTEM_H

#include "Graphic/AdVKCommon.h"
//数据更新
namespace ade{
    class AdVKRenderPass;
    class AdRenderTarget;

    class AdSystem
    {
        public:
            virtual void OnUpdate(float deltaTime){}
    };

    class AdMaterialSystem : public AdSystem
    {
        public:
            virtual void OnInit(AdVKRenderPass *renderPass) = 0;//初始化
            virtual void OnRender(VkCommandBuffer cmdBuffer, AdRenderTarget *renderTarget) = 0;//绘制
            virtual void OnDestroy() = 0;//销毁
    };
}

#endif