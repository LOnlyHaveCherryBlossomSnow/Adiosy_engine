#ifndef AD_SYSTEM_H
#define AD_SYSTEM_H

#include "Graphic/AdVKCommon.h"
//数据更新
namespace ade{
    class AdSystem
    {
        public:
            virtual void OnUpdate(float deltaTime){}
    };
}

#endif