#ifndef AD_ENTIT_H
#define AD_ENTIT_H

#include "AdNode.h"
#include "AdScene.h"
//主题
namespace ade
{
    class AdEntity :public AdNode
    {
        public:
            AdEntity(const entt::entity &ecsEntity, AdScene *scene) : mEcsEntity(ecsEntity), mScene(scene) {}
            ~AdEntity() override = default;


            static bool IsValid(AdEntity *entity)
            {
                return entity && entity->IsValid();
            }
            template<typename T>//判断是否有这个组件
            static bool HasComponent(AdEntity *entity)
            {
                return IsValid(entity) && entity -> HasComponent<T>();
            }


            bool operator==(const AdEntity& other) const
            {
                return mEcsEntity == other.mEcsEntity && mScene == other.mScene;
            }
            bool operator!=(const AdEntity& other) const
            {
                return !(*this == other);
            }

            bool IsValid() const { return mScene && mScene->mEcsRegistry.valid(mEcsEntity); }//是否是空的
            const entt::entity &GetEcsEntity() const { return mEcsEntity; }

            template<typename T, typename... Args>//添加组件
            T& AddComponent(Args &&...args)
            {
                T &component = mScene->mEcsRegistry.emplace<T>(mEcsEntity, std::forward<Args>(args)...);
                component.SetOwner(this);
                return component;
            }

            template<typename T>
            bool HasComponent()//是否包含组件
            {
                return mScene->mEcsRegistry.any_of<T>(mEcsEntity);
            }

            template<typename... T>
            bool HasAnyComponent() //其中一个包含
            {
                return mScene->mEcsRegistry.any_of<T...>(mEcsEntity);
            }

            template<typename... T>
            bool HasAllComponent()//全部包含
            {
                return mScene->mEcsRegistry.all_of<T...>(mEcsEntity);
            }

            template<typename T>
            T& GetComponent()//获取组件
            {
                assert(HasComponent<T>() && "Entity does not have component!");
                return mScene->mEcsRegistry.get<T>(mEcsEntity);
            }

            template<typename T>
            void RemoveComponent()//移除组件
            {
                assert(HasComponent<T>() && "Entity does not have component!");
                mScene->mEcsRegistry.remove<T>(mEcsEntity);
            }

        private:
            entt::entity mEcsEntity;
            AdScene *mScene;
    };

}

#endif