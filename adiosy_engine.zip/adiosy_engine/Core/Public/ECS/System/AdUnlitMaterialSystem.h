#ifndef AD_UNLIT_MATERIAL_SYSTEM_H
#define AD_UNLIT_MATERIAL_SYSTEM_H

#include "ECS/System/AdMaterialSystem.h"
#include "ECS/Component/Material/AdUnlitMaterialComponent.h"

namespace ade
{
#define NUM_MATERIAL_BATCH              16
#define NUM_MATERIAL_BATCH_MAX          2048

    class AdVKPipelineLayout;
    class AdVKPipeline;
    class AdVKDescriptorSetLayout;
    class AdVKDescriptorPool;

    class AdUnlitMaterialSystem : public AdMaterialSystem//继承根材质
    {
        public://继承材质
            void OnInit(AdVKRenderPass *renderPass) override;
            void OnRender(VkCommandBuffer cmdBuffer, AdRenderTarget *renderTarget) override;
            void OnDestroy() override;
        private:
            void ReCreateMaterialDescPool(uint32_t materialCount);//材质数量
            void UpdateFrameUboDescSet(AdRenderTarget *renderTarget);//更新每帧的Ubo
            void UpdateMaterialParamsDescSet(VkDescriptorSet descSet, AdUnlitMaterial *material);//更新材质参数
            void UpdateMaterialResourceDescSet(VkDescriptorSet descSet, AdUnlitMaterial *material);//更新材质的资源信息
            //初始化渲染管线
            std::shared_ptr<AdVKDescriptorSetLayout> mFrameUboDescSetLayout;
            std::shared_ptr<AdVKDescriptorSetLayout> mMaterialParamDescSetLayout;
            std::shared_ptr<AdVKDescriptorSetLayout> mMaterialResourceDescSetLayout;

            std::shared_ptr<AdVKPipelineLayout> mPipelineLayout;
            std::shared_ptr<AdVKPipeline> mPipeline;
            //描述符池
            std::shared_ptr<AdVKDescriptorPool> mDescriptorPool;
            std::shared_ptr<AdVKDescriptorPool> mMaterialDescriptorPool;//用于动态扩容

            VkDescriptorSet mFrameUboDescSet;
            std::shared_ptr<AdVKBuffer> mFrameUboBuffer;
            //材质
            uint32_t mLastDescriptorSetCount = 0;//描述符池数量
            //材质描述集
            std::vector<VkDescriptorSet> mMaterialDescSets;
            std::vector<VkDescriptorSet> mMaterialResourceDescSets;
            std::vector<std::shared_ptr<AdVKBuffer>> mMaterialBuffers;
       
    };
}

#endif