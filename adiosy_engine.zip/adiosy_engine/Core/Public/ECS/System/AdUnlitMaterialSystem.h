#ifndef AD_UNLIT_MATERIAL_SYSTEM_H
#define AD_UNLIT_MATERIAL_SYSTEM_H

#include "ECS/System/AdMaterialSystem.h"
#include "ECS/Component/Material/AdUnlitMaterialComponent.h"

namespace ade{
#define NUM_MATERIAL_BATCH              16
#define NUM_MATERIAL_BATCH_MAX          2048

    class AdVKPipelineLayout;
    class AdVKPipeline;
    class AdVKDescriptorSetLayout;
    class AdVKDescriptorPool;

    class AdUnlitMaterialSystem : public AdMaterialSystem
    {
       
    };
}

#endif