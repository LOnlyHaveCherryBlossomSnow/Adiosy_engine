#ifndef ADBASEMATERIALSYSTEM_H
#define ADBASEMATERIALSYSTEM_H

#include "ECS/AdSystem.h"
#include "ECS/Component/AdTransformComponent.h"
#include "ECS/Component/AdMeshComponent.h"
#include "ECS/Component/AdBaseMaterialComponent.h"
#include "AdGraphicContext.h"

namespace ade{
    class AdVKPipelineLayout;
    class AdVKPipeline;

    struct PushConstants
    {
        glm::mat4 matrix{ 1.f };//模型矩阵
        uint32_t colorType;
    };

    class AdBaseMaterialSystem : public AdMaterialSystem
    {
        public:
            void OnInit(AdVKRenderPass *renderPass) override;
            void OnRender(VkCommandBuffer cmdBuffer, AdRenderTarget *renderTarget) override;
            void OnDestroy() override;
        private:
            std::shared_ptr<AdVKPipelineLayout> mPipelineLayout;
            std::shared_ptr<AdVKPipeline> mPipeline;
    };
}

#endif