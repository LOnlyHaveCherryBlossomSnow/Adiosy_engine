#ifndef AD_MATERIAL_SYSTEM_H
#define AD_MATERIAL_SYSTEM_H

#include "AdGraphicContext.h"
#include "Graphic/AdVKCommon.h"
#include "ECS/AdSystem.h"

namespace ade
{
    
}

#endif