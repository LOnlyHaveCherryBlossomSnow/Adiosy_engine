#ifndef AD_COMPONENT_H
#define AD_COMPONENT_H
//根组件

#include "AdEntity.h"

namespace ade{
    class AdComponent
    {
        public:
            //归属  谁拥有
            void SetOwner(AdEntity *owner){mOwner = owner;}
            AdEntity *GetOwner() const {return mOwner;}

        private:
            AdEntity *mOwner = nullptr;

    };
}

#endif