#ifndef AD_COMPONENT_H
#define AD_COMPONENT_H
//根组件
namespace ade{
    class AdComponent
    {
        public:

    };
}

#endif