﻿#ifndef AD_APPLICATION_H
#define AD_APPLICATION_H

#include "AdWindow.h"
#include "AdApplicationContext.h"

namespace ade
{
    struct AppSettings//窗口
    {
        uint32_t width = 800;
        uint32_t height = 600;
        const char *title = "Adiosy Engine";
    };
    class AdApplication
    {
        public:
            static AdAppContext *GetAppContext(){ return &sAppContext;}//维护app上下文

            void Start(int argc, char *argv[]);
            void Stop();
            void MainLoop();

            void Pause() { bPause = true; }
            void Resume() { if(bPause) bPause = false; }
            bool IsPause() const { return bPause; }

        protected:
            virtual void OnConfiguration(AppSettings *appSettings){}//配置
            virtual void OnInit(){}//初始
            virtual void OnUpdate(float deltaTime){}//更新
            virtual void OnRender(){}//渲染
            virtual void OnDestroy(){}//销毁

            std::chrono::steady_clock::time_point mStartTimePoint;//程序运行 时间点
            std::chrono::steady_clock::time_point mLastTimePoint;//时间点
            std::shared_ptr<AdRenderContext> mRenderContext;
        private:
            void ParseArgs(int argc, char *argv[]);
            
            std::unique_ptr<AdWindow> mWindow;
            AppSettings mAppSettings;


            uint64_t mFrameIndex = 0;
            bool bPause = false;

            static AdAppContext sAppContext;
    };
} // namespace adde
#endif
