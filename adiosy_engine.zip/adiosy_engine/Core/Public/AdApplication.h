﻿#ifndef AD_APPLICATION_H
#define AD_APPLICATION_H

#include "AdWindow.h"
#include "AdApplicationContext.h"
#include "ECS/AdScene.h"  // 确保这个包含在文件开头


namespace ade
{
    struct AppSettings//窗口
    {
        uint32_t width = 800;
        uint32_t height = 600;
        const char *title = "Adiosy Engine";
    };
    class AdApplication
    {
        public:
            static AdAppContext *GetAppContext(){ return &sAppContext;}//维护app上下文

            void Start(int argc, char *argv[]);
            void Stop();
            void MainLoop();

            bool IsPause() const { return bPause; }
            void Pause() { bPause = true; }
            void Resume() { if(bPause) bPause = false; }

            float GetStartTimeSecond() const { return std::chrono::duration<float>(std::chrono::steady_clock::now() - mStartTimePoint).count(); }
            uint64_t GetFrameIndex() const {return mFrameIndex;}//帧的Index
        protected:
            virtual void OnConfiguration(AppSettings *appSettings){}//配置
            virtual void OnInit(){}//初始
            virtual void OnUpdate(float deltaTime){}//更新
            virtual void OnRender(){}//渲染
            virtual void OnDestroy(){}//销毁

            virtual void OnSceneInit(AdScene *scene){}//添加场景
            virtual void OnSceneDestroy(AdScene *scene){}//卸载场景

            std::chrono::steady_clock::time_point mStartTimePoint;//程序运行 时间点
            std::chrono::steady_clock::time_point mLastTimePoint;//时间点
            std::shared_ptr<AdRenderContext> mRenderContext;
           
            std::unique_ptr<AdWindow> mWindow;//窗口指针
            std::unique_ptr<AdScene> mScene;//场景指针
        private:
            void ParseArgs(int argc, char *argv[]);
            
            bool LoadScene(const std::string &filePath = "");//加载场景
            void UnLoadScene();//初始化场景

            AppSettings mAppSettings;


            uint64_t mFrameIndex = 0;
            bool bPause = false;

            static AdAppContext sAppContext;

    };
} // namespace adde
#endif
