#ifndef AD_APPLICATION_H
#define AD_APPLICATION_H

namespace adde
{
    class AdApplication
    {
        public:
    };
} // namespace adde
#endif