#ifndef ADAPPLICATIONCONTEXT_H
#define ADAPPLICATIONCONTEXT_H

namespace ade
{
    class AdApplication;
    class AdScene;//场景
    class AdRenderContext;

    struct AdAppContext
    {
        AdApplication *app;
        AdScene *scene;//场景
        AdRenderContext *renderCxt;
    };
}

#endif