#ifndef AD_SAMPLER_H
#define AD_SAMPLER_H

#include "Graphic/AdVKCommon.h"

namespace ade
{
    class AdSampler
    {
        public:
            AdSampler(VkFilter filter = VK_FILTER_LINEAR, VkSamplerAddressMode addressMode = VK_SAMPLER_ADDRESS_MODE_REPEAT);
            ~AdSampler();


            VkSampler GetHandle() const {return mHandle;}
        private:
            VkSampler mHandle = VK_NULL_HANDLE;
            //过滤方式
            //.sType = VK_STRUCTURE_TYPE_SAMPLER_CREATE_INFO,
            //.pNext = nullptr,
            //.flags = 0,
            //.magFilter = filter,
            //.minFilter = filter,过滤方式
            //.mipmapMode = VK_SAMPLER_MIPMAP_MODE_LINEAR,
            //.addressModeU = addressMode,三个方向的UV
            //.addressModeV = addressMode,三个方向的UV
            //.addressModeW = addressMode,三个方向的UV
            //.mipLodBias = 0,
            //.anisotropyEnable = VK_FALSE,
            //.maxAnisotropy = 0,
            //.compareEnable = VK_FALSE,
            //.compareOp = VK_COMPARE_OP_NEVER,
            //.minLod = 0,Lod
            //.maxLod = 1,Lod
            //.borderColor = VK_BORDER_COLOR_FLOAT_OPAQUE_BLACK,
            //.unnormalizedCoordinates = VK_FALSE
            VkFilter mFilter;
            VkSamplerAddressMode mAddressMode;
            
    };
}


#endif