#ifndef AD_RENDER_CONTEXT_H
#define AD_RENDER_CONTEXT_H

#include "Graphic/AdVKGraphicContext.h"
#include "Graphic/AdVKDevice.h"
#include "Graphic/AdVKSwapchain.h"

namespace ade
{
    class AdWindow;

    class AdRenderContext
    {
        public:
            AdRenderContext(AdWindow *window);
            ~AdRenderContext();

            AdGraphicContext *GetGraphicContext() const { return mGraphicContext.get(); }
            AdVKDevice *GetDevice() const { return mDevice.get(); }
            AdVKSwapchain *GetSwapchain() const { return mSwapchain.get(); }
        private:
            std::shared_ptr<AdGraphicContext> mGraphicContext;
            std::shared_ptr<AdVKDevice> mDevice;
            std::shared_ptr<AdVKSwapchain> mSwapchain;

    };
}

#endif