#ifndef AD_TEXTURE_H
#define AD_TEXTURE_H

#include "Graphic/AdVKCommon.h"
//传入文件夹获取图片
namespace ade
{
    class AdVKImage;
    class AdVKImageView;
    class AdVKBuffer;
    
    struct RGBAColor//每个像素的信息
    {
        uint8_t r;
        uint8_t g;
        uint8_t b;
        uint8_t a;
    };

    class AdTexture
    {
        public:
            AdTexture(const std::string &filePath);//传入文件夹
            AdTexture(uint32_t width, uint32_t height, RGBAColor *pixels);//图片的长宽高 和像素信息
            ~AdTexture();

            uint32_t GetWindth() const{return mWidth;}
            uint32_t GetHeight() const{return mHeight;}
            AdVKImage *GetImage() const{return mImage.get();}
            AdVKImageView *GetImageView() const{return mImageView.get();}
           
            // VkSampler GetSampler() const { return mSampler; }
        private:
            void CreateImage(size_t size, void *data);//图片数据大小 和所有数据

            uint32_t mWidth;
            uint32_t mHeight;
            VkFormat mFormat;//图片格式
            std::shared_ptr<AdVKImage> mImage;
            std::shared_ptr<AdVKImageView> mImageView;

            // VkSampler mSampler;
          
    };

}
#endif