#ifndef AD_MESH_H
#define AD_MESH_H

#include "Graphic/AdVKBuffer.h"
#include "AdGeometryUtil.h"


namespace ade
{
    class AdMesh
    {
        public:
            AdMesh(const std::vector<ade::AdVertex> &vertices, const std::vector<uint32_t> &indices = {});
            ~AdMesh();
            
            void Draw(VkCommandBuffer cmdBuffer);//绘制

        private:
            std::shared_ptr<ade::AdVKBuffer> mVertexBuffer;
            std::shared_ptr<ade::AdVKBuffer> mIndexBuffer;
            uint32_t mVertexCount;//顶点数量
            uint32_t mIndexCount;//索引数量

    };
}

#endif