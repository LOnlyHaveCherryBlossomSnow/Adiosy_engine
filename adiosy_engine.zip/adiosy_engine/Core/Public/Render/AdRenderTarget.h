#ifndef AD_RENDER_TARGET_H
#define AD_RENDER_TARGET_H

#include "Graphic/AdVKFrameBuffer.h"
#include "Render/AdRenderContext.h"

namespace ade
{
    class AdRenderTarget
    {
        public:
            AdRenderTarget(AdVKRenderPass *renderPass);
            AdRenderTarget(AdVKRenderPass *renderPass, uint32_t bufferCount, VkExtent2D extent);//数量
            ~AdRenderTarget();

            void Begin(VkCommandBuffer cmdBuffer);//开启
            void End(VkCommandBuffer cmdBuffer);//结束

            AdVKRenderPass *GetRenderPass() const { return mRenderPass; }
            AdVKFrameBuffer *GetFrameBuffer() const { return mFrameBuffers[mCurrentBufferIdx].get(); }

            void SetExtent(const VkExtent2D &extent);
            void SetBufferCount(uint32_t bufferCount);

            void SetColorClearValue(VkClearColorValue colorClearValue);//清空颜色
            void SetColorClearValue(uint32_t attachmentIndex, VkClearColorValue colorClearValue);
            void SetDepthStencilClearValue(VkClearDepthStencilValue depthStencilValue);//清空深度
            void SetDepthStencilClearValue(uint32_t attachmentIndex, VkClearDepthStencilValue depthStencilValue);
        private:
            void Init();
            void ReCreate();//重新调用

            std::vector<std::shared_ptr<AdVKFrameBuffer>> mFrameBuffers;

            AdVKRenderPass *mRenderPass;
            std::vector<VkClearValue> mClearValues;
            uint32_t mBufferCount;
            uint32_t mCurrentBufferIdx = 0;//当前的bf
            VkExtent2D mExtent;

            bool bSwapchainTarget = false;
            bool bBeginTarget = false;

            bool bShouldUpdate = false;//是否需要跟新
    };
    
}
#endif