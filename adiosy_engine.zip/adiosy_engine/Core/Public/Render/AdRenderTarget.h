#ifndef AD_RENDER_TARGET_H
#define AD_RENDER_TARGET_H

#include "Graphic/AdVKFrameBuffer.h"
#include "Render/AdRenderContext.h"
#include "ECS/AdSystem.h"

namespace ade
{
    class AdRenderTarget
    {
        public:
            AdRenderTarget(AdVKRenderPass *renderPass);
            AdRenderTarget(AdVKRenderPass *renderPass, uint32_t bufferCount, VkExtent2D extent);//数量
            ~AdRenderTarget();

            void Begin(VkCommandBuffer cmdBuffer);//开启
            void End(VkCommandBuffer cmdBuffer);//结束

            AdVKRenderPass *GetRenderPass() const { return mRenderPass; }
            AdVKFrameBuffer *GetFrameBuffer() const { return mFrameBuffers[mCurrentBufferIdx].get(); }

            void SetExtent(const VkExtent2D &extent);
            void SetBufferCount(uint32_t bufferCount);

            void SetColorClearValue(VkClearColorValue colorClearValue);//清空颜色
            void SetColorClearValue(uint32_t attachmentIndex, VkClearColorValue colorClearValue);
            void SetDepthStencilClearValue(VkClearDepthStencilValue depthStencilValue);//清空深度
            void SetDepthStencilClearValue(uint32_t attachmentIndex, VkClearDepthStencilValue depthStencilValue);
            //添加材质系统
            template<typename T,typename... Args>
            void AddMaterialSystem(Args&&... args) 
            {
                //实例化
                std::shared_ptr<AdMaterialSystem> system = std::make_shared<T>(std::forward<Args>(args)...);
                system->OnInit(mRenderPass);//初始化
                mMaterialSystemList.push_back(system);
            }
            //便利所有的材质系统
            void RenderMaterialSystems(VkCommandBuffer cmdBuffer)
            {
                for(auto &item: mMaterialSystemList)
                {
                    item->OnRender(cmdBuffer, this);
                }
            }

        private:
            void Init();
            void ReCreate();//重新调用

            std::vector<std::shared_ptr<AdVKFrameBuffer>> mFrameBuffers;
            //所有的材质系统
            std::vector<std::shared_ptr<AdMaterialSystem>> mMaterialSystemList;


            AdVKRenderPass *mRenderPass;
            std::vector<VkClearValue> mClearValues;
            uint32_t mBufferCount;
            uint32_t mCurrentBufferIdx = 0;//当前的bf
            VkExtent2D mExtent;

            bool bSwapchainTarget = false;
            bool bBeginTarget = false;

            bool bShouldUpdate = false;//是否需要跟新
    };
    
}
#endif