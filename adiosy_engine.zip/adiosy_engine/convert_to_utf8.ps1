# convert_to_utf8.ps1
param (
    [string]$path = "."
)

# 获取所有代码文件（你可以根据需要调整扩展名）
$files = Get-ChildItem -Path $path -Recurse -Include *.cpp, *.h, *.hpp

foreach ($file in $files) {
    # 读取文件内容并使用 UTF-8 编码重新写入
    $content = Get-Content $file.FullName
    Set-Content $file.FullName -Value $content -Encoding utf8
}

Write-Host "All files have been converted to UTF-8."
