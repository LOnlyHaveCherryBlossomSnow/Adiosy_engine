#include "Window/AdGLFWwindow.h"
#include "AdLog.h"
#include "GLFW/glfw3native.h"

namespace ade
{
    AdGLFWwindow::AdGLFWwindow(uint32_t width, uint32_t height, const char *title)
    {
        if(!glfwInit())
        {
            LOG_E("Failed to init glfw.");
            return;
        }
        glfwWindowHint(GLFW_CLIENT_API, GLFW_NO_API);
        glfwWindowHint(GLFW_VISIBLE, GL_FALSE);//设置不可见

        mGLFWwindow = glfwCreateWindow(width, height, title, nullptr, nullptr);
        if(!mGLFWwindow)
        {
            LOG_E("Failed to create glfw window");
            return;
        }

        GLFWmonitor *primaryMonitor =  glfwGetPrimaryMonitor();//显示器信息
        if(primaryMonitor)
        {
            int xPos, yPos, workWidth, workHeight;
            glfwGetMonitorWorkarea(primaryMonitor,&xPos,&yPos,&workWidth,&workHeight);
            glfwSetWindowPos(mGLFWwindow,workWidth / 2 - width / 2,workHeight / 2 - height / 2);//设置窗口居中
        }
       
         // For OpenGL/OpenGLES https://www.glfw.org/docs/latest/group__context.html#ga6d4e0cdf151b5e579bd67f13202994ed
        // This function sets the swap interval for the current OpenGL or OpenGL ES context,
        // i.e. the number of screen updates to wait from the time glfwSwapBuffers was called before swapping the buffers and returning.
        //glfwSwapInterval(0);//是否开始垂直同步
        glfwMakeContextCurrent(mGLFWwindow);

        //show window 等计算完整后显示窗口
        glfwShowWindow(mGLFWwindow);
    }
    AdGLFWwindow::~AdGLFWwindow()
    {
        glfwDestroyWindow(mGLFWwindow);//销毁mGLFWwindow
        glfwTerminate();//关闭
        LOG_I("The application running end/运行结束");
    }

    bool AdGLFWwindow::ShouldClose()
    {
        return glfwWindowShouldClose(mGLFWwindow);
    }
    void AdGLFWwindow::PollEvents()
    {
       glfwPollEvents();
    }
    void AdGLFWwindow::SwapBuffer()
    {
        glfwSwapBuffers(mGLFWwindow);
    }
}