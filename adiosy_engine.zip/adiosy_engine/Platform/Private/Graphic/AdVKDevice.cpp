﻿#include "Graphic/AdVKDevice.h"
#include "Graphic/AdVKGraphicContext.h"
#include "Graphic/AdVKQueue.h"

namespace ade
{
    const DeviceFeature requestedExtensions[] = {
            { VK_KHR_SWAPCHAIN_EXTENSION_NAME, true },
#ifdef AD_ENGINE_PLATFORM_WIN32
#elif AD_ENGINE_PLATFORM_MACOS
            { "VK_KHR_portability_subset", true },
#elif AD_ENGINE_PLATFORM_LINUX
#endif
    };
    AdVKDevice::AdVKDevice(AdVKGraphicContext *context, uint32_t graphicQueueCount, uint32_t presentQueueCount,
                            const AdVkSettings &settrings)
    {
        if(!context)
        {
            LOG_E("Must create a vulkan graphic context before create device.");
            return;
        }

        QueueFamilyInfo graphicQueueFamilyInfo = context->GetGraphicQueueFamilyInfo();
        QueueFamilyInfo presentQueueFamilyInfo = context->GetPresentQueueFamilyInfo();
        if(graphicQueueCount > graphicQueueFamilyInfo.queueCount)//鏄惁澶т簬浼犲叆鐨勯槦鍒楁暟
        {
            LOG_E("this queue family has {0} queue, but request {1}", graphicQueueFamilyInfo.queueCount, graphicQueueCount);
            return;
        } 
        if(presentQueueCount > presentQueueFamilyInfo.queueCount){
            LOG_E("this queue family has {0} queue, but request {1}", presentQueueFamilyInfo.queueCount, presentQueueCount);
            return;
        }
        std::vector<float> graphicQueuePriorties(graphicQueueCount, 0.f);
        std::vector<float> presentQueuePriorties(graphicQueueCount, 1.f);

        bool bSameQueueFamilyIndex = context ->IsSameGraphicPresentQueueFamily();
        uint32_t sameQueueCount = graphicQueueCount;//闃熷垪鏁伴噺
        if(bSameQueueFamilyIndex)
        {
            sameQueueCount += presentQueueCount;
            if(sameQueueCount > graphicQueueFamilyInfo.queueCount)
            {
                sameQueueCount = graphicQueueFamilyInfo.queueCount;
            }
            graphicQueuePriorties.insert(graphicQueuePriorties.end(), presentQueuePriorties.begin(), presentQueuePriorties.end());
        }
/*VkStructureType sType;
// 缁撴瀯浣撶殑绫诲瀷鏍囪瘑绗︺€傚繀椤昏缃负 VK_STRUCTURE_TYPE_DEVICE_QUEUE_CREATE_INFO銆?
const void* pNext;
// 鎸囧悜鎵╁睍缁撴瀯浣撶殑鎸囬拡銆傞€氬父涓?nullptr锛岄櫎闈炴湁閾惧紡鎵╁睍缁撴瀯闇€瑕侀檮鍔犮€?
VkDeviceQueueCreateFlags flags;
// 闃熷垪鍒涘缓鏍囧織銆傜洰鍓嶆病鏈変娇鐢ㄧ殑鏍囧織锛屽洜姝ら€氬父璁剧疆涓?0銆?
uint32_t queueFamilyIndex;
// 闃熷垪瀹舵棌鐨勭储寮曘€傛寚绀哄睘浜庡摢涓槦鍒楀鏃忥紝蹇呴』鏄墿鐞嗚澶囨敮鎸佺殑闃熷垪瀹舵棌涔嬩竴銆?
uint32_t queueCount;
// 瑕佸垱寤虹殑闃熷垪鏁伴噺銆傝鍊间笉鑳借秴杩囩墿鐞嗚澶囨敮鎸佺殑闃熷垪瀹舵棌涓殑鏈€澶ч槦鍒楁暟閲忋€?
const float* pQueuePriorities;
// 鎸囧悜闃熷垪浼樺厛绾ф暟缁勭殑鎸囬拡銆傛瘡涓槦鍒楃殑浼樺厛绾у繀椤诲湪 [0.0, 1.0] 鑼冨洿鍐咃紝鍊艰秺楂樿〃绀轰紭鍏堢骇瓒婇珮銆?
*/
        //鍒涘缓闃熷垪淇℃伅
        VkDeviceQueueCreateInfo queueInfos[2] =
        {
            {
                .sType = VK_STRUCTURE_TYPE_DEVICE_QUEUE_CREATE_INFO,
                .pNext = nullptr,
                .flags = 0,
                .queueFamilyIndex = static_cast<uint32_t>(graphicQueueFamilyInfo.queueFamilyIndex),
                .queueCount = sameQueueCount,
                .pQueuePriorities = graphicQueuePriorties.data()
            }
        }; 
        if(!bSameQueueFamilyIndex)
        {
            queueInfos[1] =
            {
                .sType = VK_STRUCTURE_TYPE_DEVICE_QUEUE_CREATE_INFO,
                .pNext = nullptr,
                .flags = 0,
                .queueFamilyIndex = static_cast<uint32_t>(presentQueueFamilyInfo.queueFamilyIndex), // 修改为 presentQueueFamilyInfo
                .queueCount = presentQueueCount,
                .pQueuePriorities = presentQueuePriorties.data()
            };
        }
/*VkStructureType sType; 
// 琛ㄧず缁撴瀯浣撶殑绫诲瀷锛岃繖閲屽簲璇ユ槸 VK_STRUCTURE_TYPE_DEVICE_CREATE_INFO銆?
const void* pNext; 
// 鎸囧悜鎵╁睍淇℃伅鐨勬寚閽堬紝閫氬父涓?nullptr锛岄櫎闈炴湁鎵╁睍缁撴瀯閾俱€?
VkDeviceCreateFlags flags; 
// 璁惧鍒涘缓鏍囧織锛岄€氬父璁剧疆涓?0锛屽洜涓哄綋鍓嶆病鏈夊畾涔変换浣曡澶囧垱寤烘爣蹇椼€?
uint32_t queueCreateInfoCount; 
// 鎻忚堪闃熷垪鍒涘缓淇℃伅鐨勬暟閲忥紝琛ㄧず璇ヨ澶囦腑瑕佸垱寤虹殑闃熷垪鏁伴噺銆?
const VkDeviceQueueCreateInfo* pQueueCreateInfos; 
// 鎸囧悜 VkDeviceQueueCreateInfo 缁撴瀯浣撴暟缁勭殑鎸囬拡锛屾弿杩版瘡涓槦鍒楃殑璇︾粏淇℃伅銆?
uint32_t enabledLayerCount; 
// 鍚敤鐨勮澶囧眰鐨勬暟閲忋€傚湪鐜颁唬 Vulkan 瀹炵幇涓紝璁惧灞傚凡搴熷純锛岄€氬父涓?0銆?
const char* const* ppEnabledLayerNames; 
// 鎸囧悜鍚敤鐨勮澶囧眰鍚嶇О鐨勬寚閽堟暟缁勩€傚湪鐜颁唬 Vulkan 瀹炵幇涓紝璁惧灞傚凡搴熷純锛岄€氬父涓?nullptr銆?
uint32_t enabledExtensionCount; 
// 鍚敤鐨勮澶囨墿灞曠殑鏁伴噺銆?
const char* const* ppEnabledExtensionNames; 
// 鎸囧悜鍚敤鐨勮澶囨墿灞曞悕绉扮殑鎸囬拡鏁扮粍銆?
const VkPhysicalDeviceFeatures* pEnabledFeatures; 
// 鎸囧悜 VkPhysicalDeviceFeatures 缁撴瀯浣撶殑鎸囬拡锛屾寚瀹氬惎鐢ㄧ殑鐗╃悊璁惧鐗规€с€?
*/
        uint32_t availableExtensionCount = 0;
        CALL_VK(vkEnumerateDeviceExtensionProperties(context ->GetPhyDevice(), "", &availableExtensionCount, nullptr));
        std::vector<VkExtensionProperties> availableExtensions(availableExtensionCount);
        CALL_VK(vkEnumerateDeviceExtensionProperties(context->GetPhyDevice(), "", &availableExtensionCount, availableExtensions.data()));
        uint32_t enableExtensionCount;
        const char *enableExtensions[32];
        if(!checkDeviceFeatures("Device Extension", true, availableExtensionCount, availableExtensions.data(),
                                  ARRAY_SIZE(requestedExtensions), requestedExtensions, &enableExtensionCount, enableExtensions))
            {
                return;
            }

        VkDeviceCreateInfo deviceInfo = 
        {
            .sType = VK_STRUCTURE_TYPE_DEVICE_CREATE_INFO,
            .pNext = nullptr,
            .flags = 0,
            .queueCreateInfoCount = static_cast<uint32_t>(bSameQueueFamilyIndex ? 1 : 2),
            .pQueueCreateInfos = queueInfos,
            .enabledLayerCount = 0,
            .ppEnabledLayerNames = nullptr,
            .enabledExtensionCount = enableExtensionCount,
            .ppEnabledExtensionNames = enableExtensionCount > 0 ? enableExtensions : nullptr,
            .pEnabledFeatures = nullptr
        };
        CALL_VK(vkCreateDevice(context -> GetPhyDevice(), &deviceInfo, nullptr, &mDevice));
        LOG_T("VkDevice: {0}",(void*)mDevice);


        for(int i = 0; i < graphicQueueCount; i++)
        {
            VkQueue queue;
            vkGetDeviceQueue(mDevice, graphicQueueFamilyInfo.queueFamilyIndex, i, &queue);
            mGraphicQueues.push_back(std::make_shared<AdVKQueue>(graphicQueueFamilyInfo.queueFamilyIndex, i, queue, false));
        }
        for(int i = 0; i < presentQueueCount; i++)
        {
            VkQueue queue;
            vkGetDeviceQueue(mDevice, presentQueueFamilyInfo.queueFamilyIndex, i, &queue);
            mPresentQueues.push_back(std::make_shared<AdVKQueue>(presentQueueFamilyInfo.queueFamilyIndex, i, queue, true));
        }
        

    }
    AdVKDevice::~AdVKDevice()//销毁
    {
         vkDeviceWaitIdle(mDevice);
         vkDestroyDevice(mDevice,nullptr);
    }
}
