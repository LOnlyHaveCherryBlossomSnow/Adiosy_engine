﻿#include "Graphic/AdVKGraphicContext.h"
#include "Window/AdGLFWwindow.h"
#include "Window/AdGLFWwindow.h"
// #include <unordered_set>

namespace ade
{
    //vulkan楠岃瘉灞?
    const DeviceFeature requestedLayers[]=
    {    
        {"VK_LAYER_KHRONOS_validation",true}//鍦ㄥ叧闂殑鏃跺€欐湁鎶ラ敊锛屽氨璇存€ц兘璀﹀憡
    };
    //vulkan 绐楀彛琛ㄩ潰
    const DeviceFeature requestedExtensions[] =
    {
        { VK_KHR_SURFACE_EXTENSION_NAME, true },
        #ifdef AD_ENGINE_PLATFORM_WIN32
            { VK_KHR_WIN32_SURFACE_EXTENSION_NAME, true },
        #elif AD_ENGINE_PLATFORM_MACOS
            { VK_MVK_MACOS_SURFACE_EXTENSION_NAME, true },
        #elif AD_ENGINE_PLATFORM_LINUX
            { VK_KHR_XCB_SURFACE_EXTENSION_NAME, true },
        #endif
            { VK_EXT_DEBUG_REPORT_EXTENSION_NAME, true }  // 娣诲姞 VK_EXT_debug_report
    };
    //璋冪敤鍑芥暟
    AdVKGraphicContext::AdVKGraphicContext(AdWindow *window)
    {
        CreateInstance();//鍒涘缓瀹炰緥
        CreateSurface(window);//鍒涘缓surface
        SelectPhyDevice();
    }
    //閲婃斁
    AdVKGraphicContext::~AdVKGraphicContext()
    {   
        vkDestroySurfaceKHR(mInstance, mSurface, nullptr);//閲婃斁surface
        vkDestroyInstance(mInstance, nullptr);//閲婃斁瀹炰緥
    }
    //涓€涓嚱鏁?
    static VkBool32 VkDebugReportCallback
    (
        VkDebugReportFlagsEXT                       flags,
        VkDebugReportObjectTypeEXT                  objectType,
        uint64_t                                    object,
        size_t                                      location,
        int32_t                                     messageCode,
        const char*                                 pLayerPrefix,
        const char*                                 pMessage,
        void*                                       pUserData
    )
    {
         if(flags & VK_DEBUG_REPORT_ERROR_BIT_EXT){
            LOG_E("{0}", pMessage);
        }
        if(flags & VK_DEBUG_REPORT_WARNING_BIT_EXT || flags & VK_DEBUG_REPORT_PERFORMANCE_WARNING_BIT_EXT){
            LOG_W("{0}",__FUNCTION__ , pMessage);
        }
        return VK_TRUE;
    }


    void AdVKGraphicContext::CreateInstance()
    {
         // 1. 鏋勫缓layers
        // uint32_t availableLayerCount;
        // CALL_VK(vkEnumerateInstanceLayerProperties(&availableLayerCount, nullptr));
        // VkLayerProperties availableLayers[availableLayerCount];
        // CALL_VK(vkEnumerateInstanceLayerProperties(&availableLayerCount, availableLayers));
        uint32_t availableLayerCount = 0;
        // 鑾峰彇鍙敤灞傜殑鏁伴噺
        CALL_VK(vkEnumerateInstanceLayerProperties(&availableLayerCount, nullptr));
        // 浣跨敤 vector 鏇夸唬鍙彉闀挎暟缁?
        std::vector<VkLayerProperties> availableLayers(availableLayerCount);
        // 鑾峰彇鍙敤灞傜殑淇℃伅
        CALL_VK(vkEnumerateInstanceLayerProperties(&availableLayerCount, availableLayers.data()));

        uint32_t enableLayerCount = 0;
        const char *enableLayers[32];
        if(bShouldValidate)
        {
            if(!checkDeviceFeatures("Instance Layers", false, availableLayerCount, availableLayers.data(),
                                    ARRAY_SIZE(requestedLayers), requestedLayers, &enableLayerCount, enableLayers))
                {
                    return;
                }
        }


        //2.鏋勫缓鎵╁睍extension
        uint32_t availableExtensionCount = 0;
        // 鑾峰彇鍙敤灞傜殑鏁伴噺
        CALL_VK(vkEnumerateInstanceExtensionProperties("", &availableExtensionCount, nullptr));
        // 浣跨敤 vector 鏇夸唬鍙彉闀挎暟缁?
        std::vector<VkExtensionProperties> availableExtensions(availableExtensionCount);
        // 鑾峰彇鍙敤灞傜殑淇℃伅
        CALL_VK(vkEnumerateInstanceExtensionProperties("", &availableExtensionCount, availableExtensions.data()));

        uint32_t glfwRequestedExtensionCount;
        const char ** glfwRequestedExtensions = glfwGetRequiredInstanceExtensions(&glfwRequestedExtensionCount);
        std::unordered_set<const char*> allRequestedExtensionSet;
        std::vector<DeviceFeature> allRequestedExtensions;
        for(const auto &item: requestedExtensions)
        {
            if(allRequestedExtensionSet.find(item.name) == allRequestedExtensionSet.end())
            {
                allRequestedExtensionSet.insert(item.name);
                allRequestedExtensions.push_back(item);
            }
        }
        for(int i = 0; i< glfwRequestedExtensionCount; i++)
        {
            const char *extensionName = glfwRequestedExtensions[i];
            if(allRequestedExtensionSet.find(extensionName) == allRequestedExtensionSet.end())
            {
                allRequestedExtensionSet.insert(extensionName);
                allRequestedExtensions.push_back({extensionName,true});
            }
        }



        uint32_t enableExtensionCount;
        const char *enableExtensions[32];
        if(!checkDeviceFeatures("Instance Extension", true, availableExtensionCount, availableExtensions.data(),
                                  allRequestedExtensions.size(), allRequestedExtensions.data(), &enableExtensionCount, enableExtensions))
            {
                return;
            }

        //3.create instance
        /*
             VkStructureType             sType;
             const void*                 pNext;
             VkInstanceCreateFlags       flags;
             const VkApplicationInfo*    pApplicationInfo;
             uint32_t                    enabledLayerCount;
             const char* const*          ppEnabledLayerNames;
             uint32_t                    enabledExtensionCount;
             const char* const*          ppEnabledExtensionNames;
        */
        VkApplicationInfo applicationInfo = 
        {
            .sType = VK_STRUCTURE_TYPE_APPLICATION_INFO,
            .pNext = nullptr,
            .pApplicationName = "Adiosy_Engine",
            .applicationVersion = VK_MAKE_VERSION(1,0,0),
            .pEngineName = "None",
            .engineVersion = VK_MAKE_VERSION(1,0,0),
            .apiVersion = VK_API_VERSION_1_3
        };
/*  VkStructureType                 sType;
    const void*                     pNext;
    VkDebugReportFlagsEXT           flags;
    PFN_vkDebugReportCallbackEXT    pfnCallback;
    void*                           pUserData;*/
        VkDebugReportCallbackCreateInfoEXT debugReportCallbackInfoExt = 
        {
            .sType = VK_STRUCTURE_TYPE_DEBUG_REPORT_CALLBACK_CREATE_INFO_EXT,
            .pNext = nullptr,
            .flags = VK_DEBUG_REPORT_WARNING_BIT_EXT
                        | VK_DEBUG_REPORT_PERFORMANCE_WARNING_BIT_EXT
                        | VK_DEBUG_REPORT_ERROR_BIT_EXT,
            .pfnCallback = VkDebugReportCallback
        };

        VkInstanceCreateInfo instanceInfo = 
        {
            .sType = VK_STRUCTURE_TYPE_INSTANCE_CREATE_INFO,
            .pNext = bShouldValidate? &debugReportCallbackInfoExt : nullptr,
            .flags = 0,
            .pApplicationInfo = &applicationInfo,
            .enabledLayerCount = enableLayerCount,
            .ppEnabledLayerNames = enableLayerCount > 0 ? enableLayers : nullptr,
            .enabledExtensionCount = enableExtensionCount,
            .ppEnabledExtensionNames = enableExtensionCount > 0 ? enableExtensions : nullptr
        };
        CALL_VK(vkCreateInstance(&instanceInfo,nullptr,&mInstance));
        LOG_T("{0}:instance:{1}", __FUNCTION__, (void*)mInstance);
    }

    void AdVKGraphicContext::CreateSurface(AdWindow *window)//绐楀彛琛ㄩ潰
    {
        if(!window)
        {
            LOG_E("Window is not exists.");
            return;
        }

        AdGLFWwindow *glfWwindow = dynamic_cast<AdGLFWwindow *>(window);
        if(!glfWwindow)
        {
            //fixme 浠ュ悗鍔爓indow鍙兘鍑虹幇闂
            LOG_E("this window is not a glfw window");
            return;
        }
        CALL_VK(glfwCreateWindowSurface(mInstance, glfWwindow->GetWindowHandle(), nullptr, &mSurface));
        LOG_T("{0}:Surface:{1}", __FUNCTION__, (void*)mInstance);
    }
    void AdVKGraphicContext::SelectPhyDevice()
    {   
        uint32_t phyDeviceCount = 0;
        CALL_VK(vkEnumeratePhysicalDevices(mInstance, &phyDeviceCount, nullptr));//鏌ョ湅鏈夊灏戣澶?
        // 浣跨敤 vector 浠ｆ浛鍙彉闀挎暟缁?
        std::vector<VkPhysicalDevice> phyDevices(phyDeviceCount);
        CALL_VK(vkEnumeratePhysicalDevices(mInstance, &phyDeviceCount, phyDevices.data())); // 鑾峰彇鐗╃悊璁惧淇℃伅

        uint32_t maxScore = 0;//鏈€楂樺垎璁惧
        int32_t maxScorePhyDeviceIndex = -1;
        LOG_D("----------------------------");
        LOG_D("Physical device:");
        for(int i = 0;i < phyDeviceCount;i++)
        {
            //log
            VkPhysicalDeviceProperties props;
            vkGetPhysicalDeviceProperties(phyDevices[i], &props);
            
            PrintPhyDeviceInfo(props);


            uint32_t score = GetPhyDeviceScore(props);
            uint32_t formatCount = 0;
            CALL_VK(vkGetPhysicalDeviceSurfaceFormatsKHR(phyDevices[i], mSurface, &formatCount, nullptr));
            std::vector<VkSurfaceFormatKHR> formats(formatCount);
            CALL_VK(vkGetPhysicalDeviceSurfaceFormatsKHR(phyDevices[i], mSurface, &formatCount, formats.data()));
            for(int j = 0; j < formatCount;j++)
            {
                if(formats[j].format == VK_FORMAT_B8G8R8_UNORM && formats[i].colorSpace == VK_COLOR_SPACE_SRGB_NONLINEAR_KHR)//棰滆壊绌洪棿
                {
                    score += 10;
                    break; 
                }
            }


            //query queue family 鏌ヨ闃熷垪缁?
            uint32_t queueFamilyCount = 0;
            vkGetPhysicalDeviceQueueFamilyProperties(phyDevices[i], &queueFamilyCount, nullptr);
            std::vector <VkQueueFamilyProperties> queueFamilys(queueFamilyCount);
            vkGetPhysicalDeviceQueueFamilyProperties(phyDevices[i], &queueFamilyCount, queueFamilys.data());

            LOG_D("score  --->   :{0}",score);
            LOG_D("queue fmily   :{0}",queueFamilyCount);
            if(score < maxScore)//鏈€楂樺垎璺冲嚭寰幆
            {
                continue;
            }

            for(int j = 0; j<queueFamilyCount; j++)//鏄惁瀵绘壘鍒伴槦鍒楃粍
            {
                if(queueFamilys[j].queueCount == 0)
                {
                    continue;
                }

                //1.graphic family 鐢ㄤ綔鍥惧舰娓叉煋绠＄嚎
                if(queueFamilys[j].queueFlags & VK_QUEUE_GRAPHICS_BIT)
                {
                    mGraphicQueueFamily.queueFamilyIndex = j;//娓叉煋绠＄嚎
                    mGraphicQueueFamily.queueCount = queueFamilys[j].queueCount;
                }
                //2.present family 鐢ㄤ綔鏄剧ず
                VkBool32 bSupportSurface;
                vkGetPhysicalDeviceSurfaceSupportKHR(phyDevices[i], j, mSurface, &bSupportSurface);
                if(bSupportSurface)
                {
                    mPresentQueueFamily.queueFamilyIndex = j;
                    mPresentQueueFamily.queueCount = queueFamilys[j].queueCount;
                }

                if(mGraphicQueueFamily.queueFamilyIndex >= 0 && mPresentQueueFamily.queueFamilyIndex >= 0
                    && mGraphicQueueFamily.queueFamilyIndex != mPresentQueueFamily.queueFamilyIndex)//鎵惧埌闃熷垪杩斿洖
                    {
                        break;
                    }

                if(mGraphicQueueFamily.queueFamilyIndex >= 0 && mPresentQueueFamily.queueFamilyIndex >= 0)//鏇存柊闃熷垪缁?
                {
                    maxScorePhyDeviceIndex = i;
                    maxScore = score;
                }
            }
            LOG_D("-----------------------");
            if(maxScorePhyDeviceIndex < 0)//娌℃壘鍒板悎閫傜殑
            {
                LOG_W("Maybe can to not find a suitable physical device, will 0.");
                maxScorePhyDeviceIndex = 0;
            }

            mPhyDevice = phyDevices[maxScorePhyDeviceIndex];
            vkGetPhysicalDeviceMemoryProperties(mPhyDevice, &mPhyDeviceMemProperties);
            LOG_T("{0} : phsical device:{1}, score:{2}, graphic queue:{3}:{4}, present queue:{5}:{6}",__FUNCTION__, maxScorePhyDeviceIndex, maxScore,
                    mGraphicQueueFamily.queueFamilyIndex, mGraphicQueueFamily.queueCount,
                    mPresentQueueFamily.queueFamilyIndex, mPresentQueueFamily.queueCount);
        }
    }
    /*  
    uint32_t apiVersion;
    // Vulkan API 鐨勭増鏈彿锛岃〃绀鸿澶囨敮鎸佺殑 Vulkan API 鐗堟湰銆傞€氳繃杩欎釜瀛楁鍙互鐭ラ亾鐗╃悊璁惧鏀寔鍝釜鐗堟湰鐨?Vulkan銆?

    uint32_t driverVersion;
    // 椹卞姩绋嬪簭鐗堟湰鍙凤紝琛ㄧず璁惧椹卞姩鐨勭増鏈€備笉鍚岃澶囧巶鍟嗕細浣跨敤涓嶅悓鐨勬柟寮忕紪鐮佺増鏈俊鎭€?

    uint32_t vendorID;
    // 渚涘簲鍟?ID锛屾爣璇嗚澶囩殑渚涘簲鍟嗭紙鍘傚晢锛夛紝閫氬父鐢?Vulkan 瑙勮寖鎸囧畾銆傚父瑙佸巶鍟嗗 NVIDIA銆丄MD 鍜?Intel 閮芥湁鐗瑰畾鐨?vendorID銆?

    uint32_t deviceID;
    // 璁惧 ID锛屾爣璇嗙墿鐞嗚澶囩殑鍨嬪彿锛屾瘡涓緵搴斿晢浼氫负鍏惰澶囧垎閰嶅敮涓€鐨?deviceID銆?

    VkPhysicalDeviceType deviceType;
    // 璁惧绫诲瀷锛岃〃绀虹墿鐞嗚澶囩殑绫诲瀷銆俈kPhysicalDeviceType 鏄灇涓剧被鍨嬶紝鍙兘鐨勫€煎寘鎷細
    // VK_PHYSICAL_DEVICE_TYPE_INTEGRATED_GPU锛堥泦鎴愭樉鍗★級
    // VK_PHYSICAL_DEVICE_TYPE_DISCRETE_GPU锛堢嫭绔嬫樉鍗★級
    // VK_PHYSICAL_DEVICE_TYPE_VIRTUAL_GPU锛堣櫄鎷?GPU锛?
    // VK_PHYSICAL_DEVICE_TYPE_CPU锛堝鐞嗗櫒锛夈€?

    char deviceName[VK_MAX_PHYSICAL_DEVICE_NAME_SIZE];
    // 璁惧鍚嶇О锛屾槸鐗╃悊璁惧鐨勫悕绉帮紝閫氬父鏄竴涓瓧绗︿覆锛屼緥濡?"NVIDIA GeForce GTX 1080"銆?

    uint8_t pipelineCacheUUID[VK_UUID_SIZE];
    // 绠＄嚎缂撳瓨 UUID锛岀敤浜庡敮涓€鏍囪瘑鐗╃悊璁惧銆傝繖涓?UUID 鍙互鐢ㄤ簬缂撳瓨绠＄嚎鏁版嵁锛屼娇寰楀湪鍚屼竴璁惧涓婇噸澶嶄娇鐢ㄧ紦瀛樼殑绠＄嚎淇℃伅銆?

    VkPhysicalDeviceLimits limits;
    // 鐗╃悊璁惧鐨勯檺鍒讹紙limits锛夛紝鍖呭惈璁惧鍦ㄥ悇绉嶆搷浣滀笂鐨勭‖浠堕檺鍒讹紝姣斿鏈€澶х汗鐞嗗ぇ灏忋€佹渶澶у瓨鍌ㄧ紦鍐插尯澶у皬绛夈€?

    VkPhysicalDeviceSparseProperties sparseProperties;
    // 绋€鐤忚祫婧愮殑鐗规€э紙sparseProperties锛夛紝琛ㄧず璁惧瀵圭█鐤忚祫婧愶紙濡傜█鐤忕汗鐞嗘垨缂撳啿鍖猴級鐨勬敮鎸佹儏鍐点€傝繖瀵逛簬鏌愪簺楂樻€ц兘鍜岄珮鏁堝唴瀛樼鐞嗙殑鍦烘櫙寰堥噸瑕併€?
    */
    void AdVKGraphicContext::PrintPhyDeviceInfo(VkPhysicalDeviceProperties &props)//鎵撳嵃鐗╃悊璁惧
    {
        const char *deviceType = props.deviceType == VK_PHYSICAL_DEVICE_TYPE_INTEGRATED_GPU ? "integrated gpu" :
                                 props.deviceType == VK_PHYSICAL_DEVICE_TYPE_DISCRETE_GPU ? "discrete gpu" :
                                 props.deviceType == VK_PHYSICAL_DEVICE_TYPE_VIRTUAL_GPU ? "virtual gpu" :
                                 props.deviceType == VK_PHYSICAL_DEVICE_TYPE_CPU ? "cpu" : "other";
        //璁惧椹卞姩鐨勭増鏈?
        uint32_t driverVersionMajor = VK_VERSION_MAJOR(props.driverVersion);
        uint32_t driverVersionMinor = VK_VERSION_MINOR(props.driverVersion);
        uint32_t driverVersionPatch = VK_VERSION_PATCH(props.driverVersion);
        //api
        uint32_t apiVersionMajor = VK_VERSION_MAJOR(props.apiVersion);
        uint32_t apiVersionMinor = VK_VERSION_MINOR(props.apiVersion);
        uint32_t apiVersionPatch = VK_VERSION_PATCH(props.apiVersion);


        LOG_D("-----------------------");
        LOG_D("deviceName       :{0}", props.deviceName);//鍚嶅瓧
        LOG_D("deviceType       :{0}", deviceType);//璁惧绫诲瀷
        LOG_D("vendorID         :{0}", props.vendorID);//渚涘簲鍟咺D
        LOG_D("devicaID         :{0}", props.deviceID);//璁惧ID
        LOG_D("devicaVersion    :{0}.{1}.{2}", driverVersionMajor, driverVersionMinor, driverVersionPatch);//璁惧椹卞姩鐨勭増鏈?
        LOG_D("apiVersion       :{0}.{1}.{2}", apiVersionMajor, apiVersionMinor, apiVersionPatch);//api


        LOG_D("-----------------------");
    }   

    uint32_t AdVKGraphicContext::GetPhyDeviceScore(VkPhysicalDeviceProperties &props)
    {
        VkPhysicalDeviceType deviceType = props.deviceType;
        uint32_t score = 0;
        switch (deviceType)
        {
            case VK_PHYSICAL_DEVICE_TYPE_OTHER:
                break;
            case VK_PHYSICAL_DEVICE_TYPE_INTEGRATED_GPU:
                score += 40;
                break;
            case VK_PHYSICAL_DEVICE_TYPE_DISCRETE_GPU:
                score += 30;
                break;
            case VK_PHYSICAL_DEVICE_TYPE_VIRTUAL_GPU:
                score += 20;
                break;
            case VK_PHYSICAL_DEVICE_TYPE_CPU:
                score += 10;
                break;
            case VK_PHYSICAL_DEVICE_TYPE_MAX_ENUM:
                break;
        }
        return score;
    }
}
