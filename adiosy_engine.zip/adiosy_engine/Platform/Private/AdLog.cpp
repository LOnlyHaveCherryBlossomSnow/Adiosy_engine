#include "AdLog.h"
#include "spdlog/sinks/stdout_color_sinks.h"
#include "spdlog/async.h"


namespace ade
{
    std::shared_ptr<spdlog::logger> AdLog::sLoggerInstace{};

    void AdLog::Init()
    {
        sLoggerInstace =spdlog::stderr_color_mt<spdlog::async_factory>("async_logger");
        sLoggerInstace->set_level(spdlog::level::trace);
         // change log pattern
        sLoggerInstace->set_pattern("[%H:%M:%S %z] [%n] [%^---%L---%$] [thread %t] %v");
    }
}