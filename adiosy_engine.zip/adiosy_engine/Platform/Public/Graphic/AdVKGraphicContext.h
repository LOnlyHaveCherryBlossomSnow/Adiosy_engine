#ifndef AD_VK_GRAPHIC_CONTEXT_H
#define AD_VK_GRAPHIC_CONTEXT_H

#include "AdGraphicContext.h"
#include "AdVKCommon.h"

namespace ade{
    class AdVKGraphicContext : public AdGraphicContext
    {
    public:
        AdVKGraphicContext(AdWindow *window);
        ~AdVKGraphicContext() override;

    private:
        void CreateInstance();//实例
        void CreateSurface(AdWindow *window);//窗口函数

        bool bShouldValidate = true;//是否需要验证  默认需要验证
        VkInstance mInstance;//vk实例
        VkSurfaceKHR mSurface;

    };
}

#endif