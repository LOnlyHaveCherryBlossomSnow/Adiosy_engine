﻿#ifndef AD_VK_GRAPHIC_CONTEXT_H
#define AD_VK_GRAPHIC_CONTEXT_H

#include "AdGraphicContext.h"
#include "AdVKCommon.h"
#include <vulkan/vulkan.h>


namespace ade{

    struct QueueFamilyInfo{
        int32_t queueFamilyIndex = -1;
        uint32_t queueCount;
    };

    class AdVKGraphicContext : public AdGraphicContext
    {
    public:
        AdVKGraphicContext(AdWindow *window);
        ~AdVKGraphicContext() override;

        VkInstance GetInstance() const { return mInstance; }
        VkSurfaceKHR GetSurface() const { return mSurface; }
        VkPhysicalDevice GetPhyDevice() const { return mPhyDevice; }
        const QueueFamilyInfo &GetGraphicQueueFamilyInfo() const { return mGraphicQueueFamily; }
        const QueueFamilyInfo &GetPresentQueueFamilyInfo() const { return mPresentQueueFamily; }
        VkPhysicalDeviceMemoryProperties GetPhyDeviceMemProperties() const { return mPhyDeviceMemProperties; }
        bool IsSameGraphicPresentQueueFamily() const { return mGraphicQueueFamily.queueFamilyIndex == mPresentQueueFamily.queueFamilyIndex; }

    private:
        static void PrintPhyDeviceInfo(VkPhysicalDeviceProperties &props); // 打印物理设备信息
        static uint32_t GetPhyDeviceScore(VkPhysicalDeviceProperties &props); // 评分设备性能

        void CreateInstance(); // 创建实例
        void CreateSurface(AdWindow *window); // 创建窗口
        void SelectPhyDevice(); // 选择物理设备

        bool bShouldValidate = true; // 是否需要验证，默认需要
        VkInstance mInstance; // Vulkan 实例
        VkSurfaceKHR mSurface; // Vulkan 窗口表面
        VkPhysicalDevice mPhyDevice; // Vulkan 物理设备
        QueueFamilyInfo mGraphicQueueFamily; // 渲染队列族
        QueueFamilyInfo mPresentQueueFamily; // 显示队列族
        VkPhysicalDeviceMemoryProperties mPhyDeviceMemProperties; // 物理设备内存属性
    };
}



#endif // AD_VK_GRAPHIC_CONTEXT_H
