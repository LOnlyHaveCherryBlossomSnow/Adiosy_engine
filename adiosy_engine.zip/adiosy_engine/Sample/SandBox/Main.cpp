#include <iostream>
#include "AdLog.h"
#include "AdWindow.h"
#include "AdGraphicContext.h"//渲染API


int main()
{
    std::cout<<"Hellow adiosy engine."<<std::endl;
    //debug
    ade::AdLog::Init();
    LOG_T("Hello spdlog:{0},{1},{3}",__FUNCTION__,1,0.14F,true);
    LOG_C("Hello spdlog:{0},{1},{3}",__FUNCTION__,1,0.14F,true);
    LOG_D("Hello spdlog:{0},{1},{3}",__FUNCTION__,1,0.14F,true);
    LOG_I("Hello spdlog:{0},{1},{3}",__FUNCTION__,1,0.14F,true);
    LOG_W("Hello spdlog:{0},{1},{3}",__FUNCTION__,1,0.14F,true);
    LOG_E("Hello spdlog:{0},{1},{3}",__FUNCTION__,1,0.14F,true);
    //窗口设置
    std::unique_ptr<ade::AdWindow>window = ade::AdWindow::Create(800,600, "SandBox");
    std::unique_ptr<ade::AdGraphicContext> graphicContext = ade::AdGraphicContext::Create(window.get());//vulkan 创建窗口

    //window为turn 关闭程序
    while(!window -> ShouldClose())
    {
        window->PollEvents();
        window->SwapBuffer();
    }
    

    return EXIT_SUCCESS;
}