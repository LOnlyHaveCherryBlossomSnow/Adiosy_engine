﻿#include <iostream>
#include "AdLog.h"
#include "AdWindow.h"
#include "AdGraphicContext.h"//濞撳弶鐓婣PI
#include "Graphic/AdVKDevice.h"
#include "Graphic/AdVKGraphicContext.h"


int main()
{
    std::cout<<"Hellow adiosy engine."<<std::endl;
    //debug
    ade::AdLog::Init();
    LOG_T("Hello spdlog:{0},{1},{3}",__FUNCTION__,1,0.14F,true);
    LOG_C("Hello spdlog:{0},{1},{3}",__FUNCTION__,1,0.14F,true);
    LOG_D("Hello spdlog:{0},{1},{3}",__FUNCTION__,1,0.14F,true);
    LOG_I("Hello spdlog:{0},{1},{3}",__FUNCTION__,1,0.14F,true);
    LOG_W("Hello spdlog:{0},{1},{3}",__FUNCTION__,1,0.14F,true);
    LOG_E("Hello spdlog:{0},{1},{3}",__FUNCTION__,1,0.14F,true);
    //缁愭褰涚拋鍓х枂
    std::unique_ptr<ade::AdWindow>window = ade::AdWindow::Create(800,600, "SandBox");
    std::unique_ptr<ade::AdGraphicContext> graphicContext = ade::AdGraphicContext::Create(window.get());//vulkan 閸掓稑缂撶粣妤€褰?
    std::shared_ptr<ade::AdVKDevice> device = std::make_shared<ade::AdVKDevice>(dynamic_cast<ade::AdVKGraphicContext*>(graphicContext.get()), 1, 1);

    //window娑撶皪urn 閸忔娊妫寸粙瀣碍
    while(!window -> ShouldClose())
    {
        window->PollEvents();
        window->SwapBuffer();
    }
    

    return EXIT_SUCCESS;
}
